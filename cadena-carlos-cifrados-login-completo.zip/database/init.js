const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcrypt');
const path = require('path');

const db = new sqlite3.Database(path.join(__dirname, 'security.db'));

db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS roles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre VARCHAR(50) NOT NULL UNIQUE
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS usuarios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    rol_id INTEGER NOT NULL,
    intentos_fallidos INTEGER DEFAULT 0,
    bloqueado_hasta DATETIME NULL,
    FOREIGN KEY (rol_id) REFERENCES roles(id)
  )`);

  db.run(`INSERT OR IGNORE INTO roles (nombre) VALUES ('Administrador')`);
  db.run(`INSERT OR IGNORE INTO roles (nombre) VALUES ('Usuario')`);

  // Usuario de prueba: admin / admin123 (hasheado con bcrypt, nunca en texto plano)
  const passwordPlano = 'admin123';
  bcrypt.hash(passwordPlano, 10, (err, hash) => {
    if (err) throw err;
    db.run(
      `INSERT OR IGNORE INTO usuarios (username, password_hash, rol_id) VALUES (?, ?, 1)`,
      ['admin', hash],
      function (err) {
        if (err) console.error(err);
        else console.log('✅ Base de datos lista. Usuario de prueba: admin / admin123');
        db.close();
      }
    );
  });
});
